.. _help.discord:

Discord
=======

There's a discord channel which is frequent by some `contributors <https://github.com/archlinux/archinstall/graphs/contributors>`_.

To join the server, head over to `https://discord.gg/cqXU88y <https://discord.gg/cqXU88y>`_'s server and join in.
There's not many rules other than common sense and treat others with respect.

There's the `@Party Animals` role if you want notifications of new releases which is posted in the `#Release Party` channel.
Another thing is the `@Contributors` role which you can get by writing `!verify` and verify that you're a contributor.

Hop in, I hope to see you there! : )